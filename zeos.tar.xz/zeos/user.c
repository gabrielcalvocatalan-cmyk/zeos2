#include <libc.h>

char buff[24];

int pid;
char *mseg;
int __attribute__ ((__section__(".text.main")))
  main(void)
{
    /* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
     /* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */
		
	if(write(1,"Funciona?",9) == -1)  perror();
	write(1,"\n",1);
	if(write(1,"Funciona?",-9) == -1) perror();
	write(1,"\n",1);
	
	int a = gettime();
	itoa(a,buff);
	write(1,buff,strlen(buff)); 
    	

  while(1) {

  }
}
